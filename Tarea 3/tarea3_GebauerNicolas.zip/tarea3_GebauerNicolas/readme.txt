Para correr los programas hay que correr los archivos .py 3.4.1 3.4.3 3.4.6. Los resultados quedan guardados en un archivo log con el mismo nombre y se generan imagenes de las matrices para 3.4.3 y 3.4.6

El informe está en tarea3_GebauerNicolas.pdf, generado a partir de tarea3_GebauerNicolas.md
